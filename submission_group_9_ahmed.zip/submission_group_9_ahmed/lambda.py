import requests
import os
import snowflake.connector as sf
from dotenv import load_dotenv

def lambda_handler(event, context):
     #parametrs
    
     #requasts and os parmeters
     url ='https://de-materials-tpcds.s3.ca-central-1.amazonaws.com/inventory.csv'
     dest_folder = '/tmp'
     file_name ='inventory.csv'
    
     #snowflake parametrs
     user: str = os.getenv('user')
     password: str = os.getenv('password')
     account: str = os.getenv('account')
     warehouse: str = os.getenv('warehouse')
     database: str = os.getenv('database')
     schema ='raw'
     role ='accountadmin'
     file_format_name = 'comma_csv'
     stage_name = 'inventory_stage'
     table = 'inventory'
    
     #grap inventory file from url
     response = requests.get(url)
     response.raise_for_status()
    
  

  

     #save it to temp and print file
     file_path = os.path.join(dest_folder,file_name)
     with open(file_path, 'wb') as file:
         file.write(response.content)
    
     with open(file_path, 'r') as file:
         file_content = file.read()
         print(file_content)
    
     #connect to snowflake
     conn = sf.connect(user = user,password = password, \
                       account = account, warehouse =warehouse, \
                       database =database, schema =schema,role=role
                       )
    
    
     cursor = conn.cursor()
     #use  warehouse
     use_warehouse = f"use warehouse {warehouse};"
     cursor.execute(use_warehouse)
    
    
     #use schema 
     use_schema= f"use schema {schema};"
     cursor.execute(use_schema)
    
     #create file format 
    
     create_csv_format = f"create or replace file format {file_format_name} type='csv' field_delimiter=',';"
     cursor.execute(create_csv_format)
    
     #create stage 
     create_stage = f"create or replace stage {stage_name} file_format= {file_format_name};"
     cursor.execute(create_stage)
    
     #run put statement
     run_put_statement = f"put file://{file_path} @{stage_name};"
     cursor.execute(run_put_statement)
    
    
    
     # list stage 
     list_stage = f"list @{stage_name};"
     cursor.execute(list_stage)
    
     # truncate table 
     truncate_table  = f"truncate table {schema}.{table};"
     cursor.execute(truncate_table)
    
     # copy into table 
     copy_into_query  = f"copy into  {schema}.{table} FROM @{stage_name}/{file_name} file_format={file_format_name} on_error='continue';"
     cursor.execute(copy_into_query)
    
     print('File uploded sccsufully into snowflake')
     # TODO implement
     return {
         'statusCode': 200,
         'body': "File uploded sccsufully into snowflake"
     }
